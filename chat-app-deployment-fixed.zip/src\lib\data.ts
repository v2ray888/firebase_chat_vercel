// This file can be used for future static data needs.
// All dynamic data is now fetched from the database.
