import { config } from 'dotenv';
config();

import '@/ai/flows/ai-suggested-responses.ts';
import '@/ai/flows/initial-chat-prompt.ts';